﻿using System;
using System.Collections.Generic;

class Program
{
    static Dictionary<string, int> vitorias = new Dictionary<string, int>
    {
        { "Jogador X", 0 },
        { "Jogador O", 0 },
        { "Computador", 0 }
    };

    static Dictionary<string, int> empates = new Dictionary<string, int>
    {
        { "Jogador X", 0 },
        { "Jogador O", 0 },
        { "Computador", 0 }
    };

    static Dictionary<string, int> derrotas = new Dictionary<string, int>
    {
        { "Jogador X", 0 },
        { "Jogador O", 0 },
        { "Computador", 0 }
    };

    static void Main()
    {
        while (true)
        {
            Console.Clear();
            Console.WriteLine("=== Jogo da Velha ===");
            Console.WriteLine("1 - Jogar Player vs Player");
            Console.WriteLine("2 - Jogar Player vs Computador (Fácil)");
            Console.WriteLine("3 - Jogar Player vs Computador (Difícil)");
            Console.WriteLine("4 - Mostrar Ranking");
            Console.WriteLine("5 - Zerar Ranking");
            Console.WriteLine("6 - Sair");
            Console.Write("Escolha: ");

            string opcao = Console.ReadLine();

            switch (opcao)
            {
                case "1":
                    LoopPartida(JogoPvP);
                    break;
                case "2":
                    LoopPartida(JogoVsPCFacil);
                    break;
                case "3":
                    LoopPartida(JogoVsPCDificil);
                    break;
                case "4":
                    MostrarRanking();
                    break;
                case "5":
                    ZerarRanking();
                    break;
                case "6":
                    return;
                default:
                    Console.WriteLine("Opção inválida! Pressione ENTER para continuar.");
                    Console.ReadLine();
                    break;
            }
        }
    }

    static void LoopPartida(Action partida)
    {
        while (true)
        {
            partida();
            Console.WriteLine("\nDeseja jogar novamente?");
            Console.WriteLine("1 - Sim");
            Console.WriteLine("2 - Não");
            string escolha = Console.ReadLine();

            if (escolha == "2")
                break;
        }
    }

    static void MostrarRanking()
    {
        Console.WriteLine("\n=== RANKING ===\n");

        string[] jogadores = { "Jogador X", "Jogador O", "Computador" };

        foreach (string j in jogadores)
            Console.Write($"{j,-15}");
        Console.WriteLine();

        foreach (string j in jogadores)
            Console.Write($"Vitórias: {vitorias[j],-6}");
        Console.WriteLine();

        foreach (string j in jogadores)
            Console.Write($"Empates: {empates[j],-7}");
        Console.WriteLine();

        foreach (string j in jogadores)
            Console.Write($"Derrotas: {derrotas[j],-6}");
        Console.WriteLine("\n================\n");

        Console.ReadKey();
    }

    static void ZerarRanking()
    {
        foreach (var chave in vitorias.Keys)
        {
            vitorias[chave] = 0;
            empates[chave] = 0;
            derrotas[chave] = 0;
        }
        Console.WriteLine("Ranking zerado! Pressione ENTER para continuar.");
        Console.ReadLine();
    }

    static void MostrarTabuleiro(char[] tabuleiro)
    {
        Console.Clear();
        Console.WriteLine("=== Jogo da Velha ===\n");
        Console.WriteLine($" {tabuleiro[0]} | {tabuleiro[1]} | {tabuleiro[2]} ");
        Console.WriteLine("---+---+---");
        Console.WriteLine($" {tabuleiro[3]} | {tabuleiro[4]} | {tabuleiro[5]} ");
        Console.WriteLine("---+---+---");
        Console.WriteLine($" {tabuleiro[6]} | {tabuleiro[7]} | {tabuleiro[8]} ");
    }

    static bool VerificarVencedor(char[] tabuleiro, char jogador)
    {
        int[,] combinacoes = {
            {0,1,2}, {3,4,5}, {6,7,8},
            {0,3,6}, {1,4,7}, {2,5,8},
            {0,4,8}, {2,4,6}
        };

        for (int i = 0; i < combinacoes.GetLength(0); i++)
        {
            if (tabuleiro[combinacoes[i, 0]] == jogador &&
                tabuleiro[combinacoes[i, 1]] == jogador &&
                tabuleiro[combinacoes[i, 2]] == jogador)
                return true;
        }
        return false;
    }

    // ------------------- PLAYER vs PLAYER -------------------
    static void JogoPvP()
    {
        char[] tabuleiro = { '1', '2', '3', '4', '5', '6', '7', '8', '9' };
        char jogadorAtual = 'X';
        int jogadas = 0;

        while (true)
        {
            MostrarTabuleiro(tabuleiro);
            Console.Write($"\nVez do jogador {jogadorAtual}: ");
            int posicao;
            if (!int.TryParse(Console.ReadLine(), out posicao) || posicao < 1 || posicao > 9 || tabuleiro[posicao - 1] == 'X' || tabuleiro[posicao - 1] == 'O')
                continue;

            tabuleiro[posicao - 1] = jogadorAtual;
            jogadas++;

            if (VerificarVencedor(tabuleiro, jogadorAtual))
            {
                MostrarTabuleiro(tabuleiro);
                Console.WriteLine($"\nJogador {jogadorAtual} venceu!");
                if (jogadorAtual == 'X')
                {
                    vitorias["Jogador X"]++;
                    derrotas["Jogador O"]++;
                }
                else
                {
                    vitorias["Jogador O"]++;
                    derrotas["Jogador X"]++;
                }
                break;
            }
            else if (jogadas == 9)
            {
                MostrarTabuleiro(tabuleiro);
                Console.WriteLine("\nEmpate!");
                empates["Jogador X"]++;
                empates["Jogador O"]++;
                break;
            }

            jogadorAtual = (jogadorAtual == 'X') ? 'O' : 'X';
        }
        MostrarRanking();
    }

    // ------------------- PLAYER vs PC (FÁCIL) -------------------
    static void JogoVsPCFacil()
    {
        char[] tabuleiro = { '1', '2', '3', '4', '5', '6', '7', '8', '9' };
        int jogadas = 0;

        while (true)
        {
            MostrarTabuleiro(tabuleiro);
            Console.Write("\nSua vez (X): ");
            int posicao;
            if (!int.TryParse(Console.ReadLine(), out posicao) || posicao < 1 || posicao > 9 || tabuleiro[posicao - 1] == 'X' || tabuleiro[posicao - 1] == 'O')
                continue;

            tabuleiro[posicao - 1] = 'X';
            jogadas++;

            if (VerificarVencedor(tabuleiro, 'X'))
            {
                MostrarTabuleiro(tabuleiro);
                Console.WriteLine("\nVocê venceu!");
                vitorias["Jogador X"]++;
                derrotas["Computador"]++;
                break;
            }
            else if (jogadas == 9)
            {
                MostrarTabuleiro(tabuleiro);
                Console.WriteLine("\nEmpate!");
                empates["Jogador X"]++;
                empates["Computador"]++;
                break;
            }

            Random rnd = new Random();
            int escolhaPC;
            do
            {
                escolhaPC = rnd.Next(1, 10);
            } while (tabuleiro[escolhaPC - 1] == 'X' || tabuleiro[escolhaPC - 1] == 'O');

            tabuleiro[escolhaPC - 1] = 'O';
            jogadas++;

            if (VerificarVencedor(tabuleiro, 'O'))
            {
                MostrarTabuleiro(tabuleiro);
                Console.WriteLine("\nComputador venceu!");
                vitorias["Computador"]++;
                derrotas["Jogador X"]++;
                break;
            }
        }
        MostrarRanking();
    }

    // ------------------- PLAYER vs PC (DIFÍCIL) -------------------
    static void JogoVsPCDificil()
    {
        char[] tabuleiro = { '1', '2', '3', '4', '5', '6', '7', '8', '9' };
        int jogadas = 0;

        while (true)
        {
            MostrarTabuleiro(tabuleiro);
            Console.Write("\nSua vez (X): ");
            int posicao;
            if (!int.TryParse(Console.ReadLine(), out posicao) || posicao < 1 || posicao > 9 || tabuleiro[posicao - 1] == 'X' || tabuleiro[posicao - 1] == 'O')
                continue;

            tabuleiro[posicao - 1] = 'X';
            jogadas++;

            if (VerificarVencedor(tabuleiro, 'X'))
            {
                MostrarTabuleiro(tabuleiro);
                Console.WriteLine("\nVocê venceu!");
                vitorias["Jogador X"]++;
                derrotas["Computador"]++;
                break;
            }
            else if (jogadas == 9)
            {
                MostrarTabuleiro(tabuleiro);
                Console.WriteLine("\nEmpate!");
                empates["Jogador X"]++;
                empates["Computador"]++;
                break;
            }

            // Computador joga (modo difícil)
            int melhorMovimento = MelhorJogada(tabuleiro);
            tabuleiro[melhorMovimento] = 'O';
            jogadas++;

            if (VerificarVencedor(tabuleiro, 'O'))
            {
                MostrarTabuleiro(tabuleiro);
                Console.WriteLine("\nComputador venceu!");
                vitorias["Computador"]++;
                derrotas["Jogador X"]++;
                break;
            }
        }
        MostrarRanking();
    }

    // ------------------- IA - MINIMAX -------------------
    static int MelhorJogada(char[] tabuleiro)
    {
        int melhorValor = int.MinValue;
        int melhorMovimento = -1;

        for (int i = 0; i < 9; i++)
        {
            if (tabuleiro[i] != 'X' && tabuleiro[i] != 'O')
            {
                char backup = tabuleiro[i];
                tabuleiro[i] = 'O';
                int valor = Minimax(tabuleiro, 0, false);
                tabuleiro[i] = backup;

                if (valor > melhorValor)
                {
                    melhorValor = valor;
                    melhorMovimento = i;
                }
            }
        }
        return melhorMovimento;
    }

    static int Minimax(char[] tabuleiro, int profundidade, bool isMax)
    {
        if (VerificarVencedor(tabuleiro, 'O')) return 10 - profundidade;
        if (VerificarVencedor(tabuleiro, 'X')) return profundidade - 10;

        bool cheio = true;
        for (int i = 0; i < 9; i++)
        {
            if (tabuleiro[i] != 'X' && tabuleiro[i] != 'O')
            {
                cheio = false;
                break;
            }
        }
        if (cheio) return 0;

        if (isMax)
        {
            int melhor = int.MinValue;
            for (int i = 0; i < 9; i++)
            {
                if (tabuleiro[i] != 'X' && tabuleiro[i] != 'O')
                {
                    char backup = tabuleiro[i];
                    tabuleiro[i] = 'O';
                    melhor = Math.Max(melhor, Minimax(tabuleiro, profundidade + 1, false));
                    tabuleiro[i] = backup;
                }
            }
            return melhor;
        }
        else
        {
            int melhor = int.MaxValue;
            for (int i = 0; i < 9; i++)
            {
                if (tabuleiro[i] != 'X' && tabuleiro[i] != 'O')
                {
                    char backup = tabuleiro[i];
                    tabuleiro[i] = 'X';
                    melhor = Math.Min(melhor, Minimax(tabuleiro, profundidade + 1, true));
                    tabuleiro[i] = backup;
                }
            }
            return melhor;
        }
    }
}





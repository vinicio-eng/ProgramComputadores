﻿
//declarei as variaveis com o valor padrao 0 
int a = 0;
int b = 0;

//pede para digitar o rpmeiro valor e le ele
Console.WriteLine("Digite o primerio valor: ");

string a1 = Console.ReadLine();//declaro a variavei em string para ser lida pelo Conosle.ReadLine();

Console.WriteLine();

//pede para digitar o segundo e le
Console.WriteLine("Diigte o segundo valor: ");

string b1 = Console.ReadLine(); //declaro a variavei em string para ser lida pelo Conosle.ReadLine();

//converte o valor de string para int usando Parse
a = int.Parse(a1);
b = int.Parse(b1);


//variaveis para fazer oo calculos
int soma = a + b;
int subi = a - b;
int multi = a * b;
int divi = a / b;
int resto = a % b;

Console.WriteLine();

Console.WriteLine($"O calculo dos valores {a} e {b} é:");

Console.WriteLine();

//mostra o resultado de tudo
Console.WriteLine($"Soma entre é: {soma}");
Console.WriteLine($"Subtração entre é: {subi}");
Console.WriteLine($"Multiplicação entre é: {multi}");
Console.WriteLine($"Divisão entre é: {divi}");
Console.WriteLine($"Rsto da divisão entre é: {resto}");

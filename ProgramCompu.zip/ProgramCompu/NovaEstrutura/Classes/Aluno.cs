﻿/*
Classes/Métodos
Conjunto de atributos(propriedades) e/ou
métodos
Rpresentar algo do mundo real
*/

namespace ClassesMetodos.Classes
{
    public class Aluno
    {
        public string Ra { get; set; }
        public string Nome { get; set; }
        public double Nota1bim { get; set; }
        public double Nota2bim { get; set; }

        public double Media()
        {
            return (this.Nota1bim + this.Nota2bim) / 2;
        }
    }
}

﻿namespace ClassesMetodos.Classes
{
    public class Aluno
    {
        private int QtdAulasSemestre = 80;
        private double NotaMinimaSemestre = 7.0;
        private int LimiteFaltas = 20; // Considerando 20 faltas como limite

        public string Ra { get; set; }
        public string Nome { get; set; }
        public double Nota1bim { get; set; }
        public double Nota2bim { get; set; }
        public int QtdFaltas { get; set; }

        private double Media()
        {
            return (this.Nota1bim + this.Nota2bim) / 2;
        }

        private bool Aprovado()
        {
            // Aluno aprovado se a média for maior ou igual a 7 e se as faltas não forem excessivas
            if (this.Media() >= NotaMinimaSemestre && this.QtdFaltas <= LimiteFaltas)
            {
                return true;
            }
            return false;
        }

        private bool ReprovadoFalta()
        {
            // Considera-se reprovado por falta se o número de faltas ultrapassar o limite
            if (this.QtdFaltas > LimiteFaltas)
            {
                return true;
            }
            return false;
        }

        private string Situacao()
        {
            if (this.ReprovadoFalta())
            {
                return "Reprovado por falta";
            }

            if (this.Aprovado())
            {
                return "Aprovado";
            }
            else
            {
                return "Reprovado";
            }
        }

        public void ExibirInfo()
        {
            Console.WriteLine($"Aluno: {this.Nome}");
            Console.WriteLine($"Ra: {this.Ra}");
            Console.WriteLine($"Nota 1 Bimestre: {this.Nota1bim}");
            Console.WriteLine($"Nota 2 Bimestre: {this.Nota2bim}");
            Console.WriteLine($"Média do aluno: {this.Media()}");
            Console.WriteLine($"Quantidade de Faltas no semetre: {this.QtdFaltas}");
            Console.WriteLine($"Situação: {this.Situacao()}");
        }
    }
}

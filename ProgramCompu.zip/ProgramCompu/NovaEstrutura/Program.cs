﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using ClassesMetodos.Classes;

namespace ClassesMetodos.Classes
{
    public class GerenciarArquivo
    {
        static void Main(string[] args)
        {
            // Caminho do arquivo CSV (pode mudar conforme seu projeto)
            string caminho = @"C:\Users\2025105254\Desktop\ProgramCompu\NovaEstrutura\aluno.csv";

            // Lê a lista de alunos
            List<Aluno> alunos = LerListaDeAlunos(caminho);

            // Percorre a lista e mostra as informações de cada aluno
            foreach (Aluno aluno in alunos)
            {
                aluno.ExibirInfo();
            }
        }

        // ---------- MÉTODOS ----------

        // Lê o arquivo CSV e retorna uma lista de linhas (strings)
        static List<string> LerCSV(string caminho)
        {
            List<string> linhas = File.ReadAllLines(caminho).ToList();
            return linhas;
        }

        // Transforma uma linha do CSV em um objeto Aluno
        static Aluno LinhaParaAluno(string linha)
        {
            string[] partes = linha.Split(';');

            Aluno aluno = new Aluno
            {
                Nome = partes[0],
                Ra = partes[1],
                Nota1bim = double.Parse(partes[2]),
                Nota2bim = double.Parse(partes[3]),
                QtdFaltas = int.Parse(partes[4])


            };

            return aluno;
        }

        // Lê todas as linhas e converte em uma lista de alunos
        static List<Aluno> LerListaDeAlunos(string caminho)
        {
            List<string> linhas = LerCSV(caminho);
            List<Aluno> alunos = new List<Aluno>();

            foreach (string linha in linhas)
            {
                alunos.Add(LinhaParaAluno(linha));
            }

            return alunos;
        }
    }
}





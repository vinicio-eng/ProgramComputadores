﻿using System.Globalization;
using ClassesMetodos.Classes;
using Microsoft.VisualBasic;

var listAlunos = new List<Aluno>();

/*
//carregar dados do csv
for (int i = 0; i < 2; i++)
{
    var al1 = RetornarAluno();
    listAlunos.Add(al1);
}
*/




foreach(var aluno in listAlunos)
{
    ExibirInfoAluno(aluno);
}

string RetornarTexto(string msg)
{
    Console.WriteLine(msg);
    return Console.ReadLine();
}

double RetornarValor(string msg)
{
    Console.WriteLine(msg);
    double.TryParse(Console.ReadLine(), out double valor);
    return valor;
}

Aluno RetornarAluno()
{
    var aluno = new Aluno();
    aluno.Ra = RetornarTexto("RA: ");
    aluno.Nome = RetornarTexto("NOME: ");
    aluno.Nota1bim = RetornarValor("NOTA 1: ");
    aluno.Nota2bim = RetornarValor("NOTA 2: ");
    return aluno;  
}

void ExibirInfoAluno(Aluno aluno)
{
    Console.WriteLine($"ALUNOS: ");
    Console.WriteLine($"Aluno: {aluno.Nome}");
    Console.WriteLine($"Ra: {aluno.Ra}");
    Console.WriteLine($"Nota 1 Bimestre: {aluno.Nota1bim}");
    Console.WriteLine($"Nota 2 BImestre: {aluno.Nota2bim}");
    Console.WriteLine($"Média do aluno: {aluno.Media()}\n");
}



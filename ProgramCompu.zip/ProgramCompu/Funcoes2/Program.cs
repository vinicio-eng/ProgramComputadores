﻿string RetornaOperador()
{
    Console.WriteLine("+, -, *, /");

    string operador = Console.ReadLine();
    return operador;
}

float RetornarValor()
{
    Console.WriteLine("Digite um valor: ");

    float valor = float.Parse(Console.ReadLine());
    return valor;
}

float Somar(float a, float b)
{
    float soma = a + b;
    return soma;
}

float Divisao(float a, float b)
{
    float divisao = a / b;
    return divisao;
}

float Subtracao(float a, float b)
{
    float subtracao = a - b;
    return subtracao;
}

float Multiplicacao(float a, float b)
{
    float multiplicacao = a + b;
    return multiplicacao;
}

void Calcular()
{
    string operador = RetornaOperador();
    float valor1 = RetornarValor();
    float valor2 = RetornarValor();
    float resultado = 0;


    switch (operador)
    {
        case "+":
            resultado = Somar(valor1, valor2);
            break;

        case "-":
            resultado = Subtracao(valor1, valor2);
            break;

        case "*":
            resultado = Multiplicacao(valor1, valor2);
            break;

        case "/":
            resultado = Divisao(valor1, valor2);
            break;

        default:
            Console.WriteLine("O operador é invalido");
            return;
    }


    Console.WriteLine($"O resultado do calculo é: {resultado} ");

}

Calcular();


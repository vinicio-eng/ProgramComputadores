﻿//DICIONARIOS

/*
var alunos = new Dictionary<int, string>();
alunos.Add(2025105254, "Vinicius de Almeida Pereira");

int ra = 2025105254;
string nome = alunos[ra];
*/

/*
using System.Threading.Channels;

var nome = new Dictionary<int, string>();
var preco = new Dictionary<int, double>();

int ids;
int produtos;
int precos;


while (true)
{

    Console.WriteLine("ID: ");
    string idtxt = Console.ReadLine();
    int.TryParse(idtxt, out ids);

    Console.WriteLine("NOME: ");
    string produtostxt = Console.ReadLine();
    int.TryParse(produtostxt, out int produto);
    nome.Add(ids, produtos);

    Console.WriteLine("PREÇOS: ");
    precos = Console.ReadLine();
    int.TryParse(precos, out precos);
    preco.Add(ids, precos);

    Console.WriteLine("DESEJA CONTINUAR?");
    Console.WriteLine("SIM: 1, NÃO: -1");
    string respostatxt = Console.ReadLine();
    int.TryParse(respostatxt, out int resposta);
    
    if(resposta == -1)
        break;

}

Console.WriteLine($"\n ID: {ids} NOME: {nome}  PREÇOS: {preco}");
*/

var nome = new Dictionary<int, string>();
var preco = new Dictionary<int, double>();

while (true)
{
    Console.WriteLine("Id: ");
    string idtxt = Console.ReadLine();
    if (!int.TryParse(idtxt, out int ids))
    {
        Console.WriteLine("ID inválido. Tente novamente.");
        continue;
    }

    Console.WriteLine("Nomw produto: ");
    string produtostxt = Console.ReadLine();
    string produtos = produtostxt;

    Console.WriteLine("Preço: ");
    string precotxt = Console.ReadLine();
    if (!double.TryParse(precotxt, out double precos))
    {
        Console.WriteLine("Preço inválido. Tente novamente.");
        continue;
    }

    nome.Add(ids, produtos);
    preco.Add(ids, precos);

    Console.WriteLine("DESEJA CONTINUAR?");
    Console.WriteLine("SIM: 1, NÃO: -1");
    string respostatxt = Console.ReadLine();
    if (!int.TryParse(respostatxt, out int resposta))
    {
        Console.WriteLine("Resposta inválida. Encerrando.");
        break;
    }

    if (resposta == -1)
        break;
}

Console.WriteLine("\nProdutos cadastrados:");

foreach (var id in nome.Keys)
{
    Console.WriteLine($"ID: {id} | NOME: {nome[id]} | PREÇO: {preco[id]:C2}");
}

// Calcular maior preço, quantidade e soma total
double maiorPreco = preco.Values.Max();
int quantidadeProdutos = nome.Count;
double somaPrecos = preco.Values.Sum();

Console.WriteLine($"\nMaior preço cadastrado: {maiorPreco:C2}");
Console.WriteLine($"Quantidade total de produtos: {quantidadeProdutos}");
Console.WriteLine($"Soma de todos os preços: {somaPrecos:C2}");

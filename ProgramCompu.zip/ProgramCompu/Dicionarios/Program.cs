﻿/*

//DICIONARIOS

int[] numeros = new int[] {1, 2, 3};
int[] valores = new int[4];

List<string> palavras = new List<string>(); //cria um dicionario (List), quase um array, com o nome de "palavras"


palavras.Add("barril de goblins"); //adiciona palavras ao dicionario "palavras"
palavras.Add("corredor");


Console.WriteLine($"numeros {numeros.Length}");
Console.WriteLine($"valores {valores.Length}");
Console.WriteLine($"palavras {palavras.Count}");

Console.WriteLine($"primeiro indice de palavras {palavras[0]}");
*/

List<int> valores = new List<int>();

int valor;

Console.WriteLine("Digite -1 se quiser parar o programa.");
while (true)
{
    Console.WriteLine("Digite um valor: ");
    string valortxt = (Console.ReadLine());
    int.TryParse(valortxt, out valor);

        if (valor == -1)
        break;

    valores.Add(valor);
}

valores.Sort(); //ordena lista
Console.WriteLine($"Total de valores digitados: {valores.Count}"); //mostra quantos itens tem na lista
Console.WriteLine("Valores digitados: " +string.Join(" ; ", valores)); //mostra os iten na lista separados por ;
Console.WriteLine("Maior: " + valores.Max()); //maior
Console.WriteLine("Menor: " + valores.Min()); //menor
Console.WriteLine("Soma: " + valores.Sum()); //soma
Console.WriteLine("Média: " + valores.Average()); //media

//chave: valor
//Dicionario de dados
//chave é unica não permite duplicar

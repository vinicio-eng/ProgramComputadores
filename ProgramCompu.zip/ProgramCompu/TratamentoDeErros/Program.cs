﻿/*
try{
//código que deve ser executado
}
catch{
//se der erro o que deve ser feito
throw;
}
*/

while (true)

{
    try
    {
        string[] palavras = new string[]
    {
    "Teste", "Abc", "Erro"
    };
        int idx = new Random().Next(0, 50);

        string palavra = palavras[idx];
        Console.WriteLine(palavra);
    }
    catch (IndexOutOfRangeException ex)
    {
        Console.WriteLine($"{DateTime.Now} - Indice não existe {ex}");
    }

    catch (Exception ex)
    {
        string msgErro = ex.ToString();
        Console.WriteLine($"{ DateTime.Now} Erro ao ler indice do Array! {msgErro} ");

    }
    Console.ReadKey();
}


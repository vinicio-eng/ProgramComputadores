﻿
    static void Main()
    {
        string caminho = "dados.csv"; // nome do arquivo (mesmo nome que você criou)

        // Verifica se o arquivo existe
        if (!File.Exists(caminho))
        {
            Console.WriteLine("Arquivo dados.csv não encontrado!");
            return;
        }

        // Lê todas as linhas do arquivo
        string[] linhas = File.ReadAllLines(caminho);

        double maiorMedia = 0;
        string alunoMaiorMedia = "";

        // Pular o cabeçalho
        for (int i = 1; i < linhas.Length; i++)
        {
            string linha = linhas[i];
            string[] partes = linha.Split(';'); // Quebra em colunas

            string nome = partes[1];
            double nota1 = double.Parse(partes[2]);
            double nota2 = double.Parse(partes[3]);
            double media = (nota1 + nota2) / 2;

            Console.WriteLine($"Aluno: {nome} - Média: {media:F2}");

            if (media > maiorMedia)
            {
                maiorMedia = media;
                alunoMaiorMedia = nome;
            }
        }

        Console.WriteLine();
        Console.WriteLine($"Aluno com maior média: {alunoMaiorMedia} {maiorMedia:F2}");
    }


﻿class Program
{
    static void Main()
    {
        string sistemaNome = "CadastrosDeTarefas";
        string dataAtual = DateTime.Now.ToString("yyyy_MM_dd");
        string arquivoNome = $"{sistemaNome}_{dataAtual}.txt";

        try
        {
            // Verifica se o arquivo existe. Se não existir, cria um novo arquivo vazio
            if (!File.Exists(arquivoNome))
            {
                File.Create(arquivoNome).Dispose();
            }

            // Carrega as tarefas do arquivo para uma lista
            List<string> listaTarefas = new List<string>(File.ReadAllLines(arquivoNome));

            int opcao = -1; // Inicializa com valor inválido
            do
            {
                // Exibe o menu de opções para o usuário


                Console.Clear();

                Console.WriteLine("NOMES:");

                Console.WriteLine("Vinicius de ALmeida Pereira, 2025105254\n" +
    "Andre Heber Azeredo Coutinho, 2025105960\n" +
    "Eduardo Gulart Da Silva, 2025106413\n" +
    "Gustavo Von Scheidt, 2025104666\n");

                Console.WriteLine("Menu:");
                Console.WriteLine("1 - Listar Tarefas");
                Console.WriteLine("2 - Inserir nova Tarefa");
                Console.WriteLine("3 - Alterar Tarefa");
                Console.WriteLine("4 - Excluir Tarefa");
                Console.WriteLine("0 - Sair");


                // Loop de leitura de entrada até o usuário inserir um valor válido
                while (true)
                {
                    Console.Write("Escolha uma opção: ");
                    string input = Console.ReadLine();

                    if (int.TryParse(input, out opcao) && opcao >= 0 && opcao <= 4)
                    {
                        break; // Sai do loop quando a opção for válida
                    }
                    else
                    {
                        Console.WriteLine("Opção inválida! Tente novamente.");
                    }
                }

                // Ação conforme a opção escolhida
                switch (opcao)
                {
                    case 1:
                        ListarTarefas(listaTarefas);
                        break;
                    case 2:
                        InserirTarefa(listaTarefas, arquivoNome);
                        break;
                    case 3:
                        AlterarTarefa(listaTarefas, arquivoNome);
                        break;
                    case 4:
                        ExcluirTarefa(listaTarefas, arquivoNome);
                        break;
                    case 0:
                        // Mensagem de saída
                        Console.WriteLine("Saindo...");
                        break;
                }

            } while (opcao != 0); // Continua até o usuário escolher sair (opção 0)

        }
        catch (IOException ex)
        {
            // Captura e exibe erro de I/O (problemas com leitura/gravação de arquivos)
            Console.WriteLine($"Erro ao acessar o arquivo: {ex.Message}");
        }
        catch (Exception ex)
        {
            // Captura e exibe qualquer outro erro inesperado
            Console.WriteLine($"Ocorreu um erro inesperado: {ex.Message}");
        }
    }

    // Método para listar todas as tarefas
    static void ListarTarefas(List<string> tarefas)
    {
        try
        {
            Console.Clear();
            Console.WriteLine("Tarefas:");
            if (tarefas.Count == 0)
            {
                // Se não houver tarefas, informa ao usuário
                Console.WriteLine("Nenhuma tarefa cadastrada.");
            }
            else
            {
                // Exibe todas as tarefas com índice
                for (int i = 0; i < tarefas.Count; i++)
                {
                    Console.WriteLine($"{i + 1}. {tarefas[i]}");
                }
            }
            Console.WriteLine("Pressione qualquer tecla para continuar...");
            Console.ReadKey();
        }
        catch (Exception ex)
        {
            // Captura qualquer erro durante a listagem das tarefas
            Console.WriteLine($"Erro ao listar as tarefas: {ex.Message}");
        }
    }

    // Método para inserir uma nova tarefa
    static void InserirTarefa(List<string> tarefas, string arquivoNome)
    {
        try
        {
            Console.Clear();
            Console.Write("Digite a nova tarefa: ");
            string novaTarefa = Console.ReadLine(); // Lê a nova tarefa do usuário

            tarefas.Add(novaTarefa); // Adiciona a tarefa à lista

            // Salva todas as tarefas no arquivo
            File.WriteAllLines(arquivoNome, tarefas);

            Console.WriteLine("Tarefa adicionada com sucesso!");
            Console.WriteLine("Pressione qualquer tecla para continuar...");
            Console.ReadKey();
        }
        catch (IOException ex)
        {
            // Captura erros ao salvar no arquivo (por exemplo, erro de permissão)
            Console.WriteLine($"Erro ao salvar no arquivo: {ex.Message}");
        }
        catch (Exception ex)
        {
            // Captura outros erros inesperados
            Console.WriteLine($"Erro inesperado: {ex.Message}");
        }
    }

    // Método para alterar uma tarefa existente
    static void AlterarTarefa(List<string> tarefas, string arquivoNome)
    {
        try
        {
            Console.Clear();
            Console.WriteLine("Selecione o número da tarefa que deseja alterar:");
            ListarTarefas(tarefas); // Lista todas as tarefas

            if (tarefas.Count == 0)
            {
                // Se não houver tarefas, não há o que alterar
                Console.WriteLine("Nenhuma tarefa para alterar.");
                Console.WriteLine("Pressione qualquer tecla para continuar...");
                Console.ReadKey();
                return;
            }

            int indice;
            Console.Write("Digite o número da tarefa: ");
            // Valida se o número digitado está dentro do intervalo de tarefas
            while (!int.TryParse(Console.ReadLine(), out indice) || indice < 1 || indice > tarefas.Count)
            {
                Console.Write("Número inválido. Tente novamente: ");
            }

            // Lê a nova descrição da tarefa
            Console.Write("Digite a nova descrição da tarefa: ");
            tarefas[indice - 1] = Console.ReadLine();

            // Atualiza o arquivo com a lista de tarefas modificada
            File.WriteAllLines(arquivoNome, tarefas);

            Console.WriteLine("Tarefa alterada com sucesso!");
            Console.WriteLine("Pressione qualquer tecla para continuar...");
            Console.ReadKey();
        }
        catch (IOException ex)
        {
            // Captura erro de I/O ao salvar o arquivo
            Console.WriteLine($"Erro ao salvar no arquivo: {ex.Message}");
        }
        catch (Exception ex)
        {
            // Captura outros erros inesperados
            Console.WriteLine($"Erro inesperado: {ex.Message}");
        }
    }

    // Método para excluir uma tarefa
    static void ExcluirTarefa(List<string> tarefas, string arquivoNome)
    {
        try
        {
            Console.Clear();
            Console.WriteLine("Selecione o número da tarefa que deseja excluir:");
            ListarTarefas(tarefas); // Lista as tarefas para o usuário

            if (tarefas.Count == 0)
            {
                // Se não houver tarefas, não há o que excluir
                Console.WriteLine("Nenhuma tarefa para excluir.");
                Console.WriteLine("Pressione qualquer tecla para continuar...");
                Console.ReadKey();
                return;
            }

            int indice;
            Console.Write("Digite o número da tarefa: ");
            // Valida se o número digitado está correto
            while (!int.TryParse(Console.ReadLine(), out indice) || indice < 1 || indice > tarefas.Count)
            {
                Console.Write("Número inválido. Tente novamente: ");
            }

            // Remove a tarefa selecionada da lista
            tarefas.RemoveAt(indice - 1);

            // Salva a lista atualizada no arquivo
            File.WriteAllLines(arquivoNome, tarefas);

            Console.WriteLine("Tarefa excluída com sucesso!");
            Console.WriteLine("Pressione qualquer tecla para continuar...");
            Console.ReadKey();
        }
        catch (IOException ex)
        {
            // Captura erros ao salvar o arquivo após exclusão
            Console.WriteLine($"Erro ao salvar no arquivo: {ex.Message}");
        }
        catch (Exception ex)
        {
            // Captura erros inesperados
            Console.WriteLine($"Erro inesperado: {ex.Message}");
        }
    }
}

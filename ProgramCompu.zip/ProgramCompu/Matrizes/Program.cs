﻿/*
    0    1    2
0 [10] [20] [30]  
1 [40] [50] [60]
2 [70] [80] [90]  

|
V
Isso é uma matriz, um array com mais de uma dimenção, precisa ser informado qual a posiçao da "linha" e "coluna"
  

exemplo: 

int[,] num new int[3, 3];

    0    1    2
0 [10] [20] [30]  
1 [40] [50] [60]
2 [70] [80] [90]  


*/

int[,] matriz = new int[3, 3];

matriz[0, 0] = 10;
matriz[0, 1] = 20;
matriz[0, 2] = 30;


matriz[1, 0] = 50;
matriz[1, 1] = 60;
matriz[1, 2] = 70;


matriz[2, 0] = 90;
matriz[2, 1] = 100;
matriz[2, 2] = 110;

for (int l = 0; l < matriz.GetLength(0); l++)
{
    for (int c = 0; c < matriz.GetLength(1); c++)
    {
        Console.Write($"[{matriz[l, c]}] ");
    }
    Console.WriteLine();
}
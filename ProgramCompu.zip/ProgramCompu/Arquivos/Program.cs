﻿using System.ComponentModel.DataAnnotations;

void Executar()
{
    string nomeArquivoEntrada = @"C:\Users\2025105254\Desktop\Teste.txt";
    string nomeEquivoSaida = @"C:\Users\2025105254\Desktop\TestePares.txt";

    // arquivo .txt com linhas
    var linhas = LerArquivo(nomeArquivoEntrada);

    // Exibe uma separação visual para a leitura do arquivo completo
    Console.WriteLine("=== Início da Leitura Completa do Arquivo ===");

    // foreach para ler cada linha do arquivo
    foreach (var linha in linhas)
    {
        Console.WriteLine(linha);
    }

    // Adiciona uma linha de separação
    Console.WriteLine("===========================================");

    // lista para as linhas
    var linhasPares = new List<string>();
    int i = 0;

    // Exibe uma separação para indicar onde as linhas pares começam
    Console.WriteLine("=== Início das Linhas Pares ===");

    // foreach para ler cada linha do arquivo
    foreach (var linha in linhas) // Alterei de linhasPares para linhas
    {
        // lê apenas as linhas pares
        if (i % 2 == 0)  // Corrigi o erro de ponto e vírgula no if
        {
            Console.WriteLine(linha);
            linhasPares.Add(linha); // Agora adiciona a linha na lista correta
        }
        i++;
    }

    // Adiciona uma linha de separação
    Console.WriteLine("===========================================");

    // Escrever as linhas pares no arquivo de saída
    EscreverArquivos(nomeEquivoSaida, linhasPares);
    Console.WriteLine("Linhas pares foram gravadas no arquivo de saída.");
}

string[] LerArquivo(string arquivoNome)
{
    try
    {
        var linhas = File.ReadAllLines(arquivoNome);
        return linhas;
    }
    catch (Exception ex)
    {
        Console.WriteLine($"Erro ao ler arquivo: {ex}");
        return new string[] { };
    }
}

void EscreverArquivos(string arquivoNome, List<string> linhas)
{
    try
    {
        File.WriteAllLines(arquivoNome, linhas);
    }
    catch (Exception ex)
    {
        Console.WriteLine($"Erro ao escrever arquivo: {ex}");
        throw ex;
    }
}

void EscreverArquivo2(string arquivoNome, string linha)
{
    try
    {
        File.AppendAllText(arquivoNome, $"{linha}");
    }

    catch (Exception ex)
    {
        Console.WriteLine($"\n{DateTime.Now} - Ocorreu um erro inesperado, parando aplicação... {ex}");
        throw ex;
    }
}

void EscreverArquivo3(string arquivoNome, List<string> linhas)
{
    try
    {
        File.AppendAllLines(arquivoNome, linhas);

    }

    catch (Exception ex)
    {
        Console.WriteLine($"\n{DateTime.Now} -Ocorreu um erro inesperado, parando aplicação... {ex}");
        throw ex;
    }
}


void AddLinhasArquivos(string arquivoNome, string linhas)
{
    try
    {
        var sw = new StreamWriter(arquivoNome, false);
        //abre loop
        sw.WriteLine(linhas);
        //fecha loop
        sw.Close();
    }
    catch (Exception ex)
    {
        Console.WriteLine($"\n{DateTime.Now} -Ocorreu um erro inesperado,  parando aplicação... {ex}");
        throw ex;
    }
}

void LerStreamReader(string arquivNome)
{
    try
    {
        var sr = new StreamReader(arquivNome);
        var linha = sr.ReadLine();
        while (linha != null)
        {
            //Console.WriteLine(linha);
            linha = sr.ReadLine();
        }
        sr.Close();
    }

    catch (Exception ex)
    {
        Console.WriteLine($"\n{DateTime.Now} -Ocorreu um erro inesperado, parando aplicação... {ex}");
        throw ex;
    }
}

Executar();

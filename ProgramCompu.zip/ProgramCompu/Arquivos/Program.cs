﻿void Executar()
{
    string nomeArquivoEntrada = @"C:\Users\2025105254\Desktop\Teste.txt";
    string nomeEquivoSaida = @"C:\Users\2025105254\Desktop\TestePares.txt";

    //arquivo .txt com linhas
    var linhas = LerArquivo(nomeArquivoEntrada);
    

    //foreach para ler cada linha do arquivo
    foreach (var linha in linhas)
    {
        Console.WriteLine(linha);
    }

    //lista para as linhas
    var linhasPares = new List<string>();
    int i = 0;

    //foreach para ler cada linha do arquivo
    foreach (var linha in linhasPares)
    {
        //le apenas as linhas pares
        Console.WriteLine(linha);
        if (i % 2 == 0) ;
        linhasPares.Add(linha);
        i++;
    }

    EscreverArquivos(nomeEquivoSaida, linhasPares);
}

string[] LerArquivo(string arquivoNome)
{
    try
    {   
        var linhas = File.ReadAllLines(arquivoNome);
        return linhas;
    }
    catch (Exception ex)
    {
        Console.WriteLine($"Erro ao ler arquivo.{ex}");
        //throw ex;
        return new string[] { };
    }
}

void EscreverArquivos(string arquivoNome, List<string> linhas )
{
    try
    {
        File.WriteAllLines(arquivoNome, linhas);
    }
    catch (Exception ex)
    {
        Console.WriteLine($"Erro ao ler arquivo.{ex}");
        throw ex;

    }

}

Executar();


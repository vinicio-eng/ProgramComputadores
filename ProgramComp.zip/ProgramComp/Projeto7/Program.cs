﻿/*
Vetores - Arrays

[] - colchetes

int[] nums = new int[3];

valor   : [10] [20] [30]
indices :  0    1    2

primeiro valor: mums[]


Adiciona um valor para cada posição do Array
exemplo: 

int[] nums = new int[3];

nums[0] = 10;
nums[1] = 20;
nums[2] = 30;
*/

int[] nums = new int[3];

Console.WriteLine($"Indice 0: {nums[0]}");
Console.WriteLine($"Indice 1: {nums[1]}");
Console.WriteLine($"Indice 2: {nums[2]}");

nums[0] = 10;
nums[1] = 20;
nums[2] = 30;


Console.WriteLine();

Console.WriteLine($"Indice 0: {nums[0]}");
Console.WriteLine($"Indice 1: {nums[1]}");
Console.WriteLine($"Indice 2: {nums[2]}");

Console.WriteLine();

int a = 0;//inicio
while (a < nums.Length)//condição
{
    Console.WriteLine($"Indice {a}: {nums[a]}");
    a++;//incremento
}

Console.WriteLine();

for (int i = 0; i < nums.Length; i++)
{
    Console.WriteLine($"Indice {i}: {nums[i]}");
}

Console.WriteLine();

int idx = 0;
foreach (var num in nums)
{
    Console.WriteLine($"{idx}: {num}");
    idx++;
}
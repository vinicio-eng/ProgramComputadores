﻿/*
Executar uma rotina
(opicional)Parâmetros: valores de entrada
(opcional)Retorno

retorno NoeMetodo()
{

}

camelcase > variaveis e parâmetros
PascalCase > 
*/

void EscreverOlaMundo()
{
    Console.WriteLine("Hello, World!");
}

EscreverOlaMundo();

void SomarDoisValores(int valor1, int valor2)
{
    //int valor1 = 10;
    //int valor2 = 20;

    int resultsoma = valor1 + valor2;

    Console.WriteLine($"A soma de {valor1} + {valor2} é: {resultsoma}");
}

SomarDoisValores(10, 10); 

int SolicitarValorInteiro()
{
    Console.WriteLine("Digite o valor: ");
    string texto1 = Console.ReadLine();
    int.TryParse(texto1, out int valor1);

    return valor1;
}

int SolicitarValorInteiro2(int valor1, int valor2)
{
    int resultsoma = valor1 + valor2;

    return resultsoma;
}


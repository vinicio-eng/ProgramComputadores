﻿

class Jogo
{
    static void Main()
    {
        Console.WriteLine("NOME: Vincius de Almeida Pereira, RA: 2025105254");
        Console.WriteLine("NOME: Eduardo Gulart da Silva, RA: 2025106413");
        Console.WriteLine("NOME: Gustavo Von Scheidt, RA: 2025104666 ");
        Console.WriteLine("NOME: André Heber Azeredo Coutinho, RA: 2025105960");

        Console.WriteLine();

        string[] bancoDePalavras = { "PROGRAMAR", "MOUSE", "BRASIL", "COMPUTADOR", "TECLADO", "FUTEBOL", "MONITOR", "MESSI", "RONALDO", "NEYMAR" };

        Random sorteador = new Random();
        int indiceSorteado = sorteador.Next(0, bancoDePalavras.Length);

        string palavraSecreta = bancoDePalavras[indiceSorteado];

        char[] letrasDescobertas = new char[palavraSecreta.Length];

        for (int i = 0; i < letrasDescobertas.Length; i++)
        {
            letrasDescobertas[i] = '_';
        }

        int maximoDeTentativas = palavraSecreta.Length * 2;
        int tentativasGastas = 0;
        bool jogadorVenceu = false;

        Console.WriteLine("--- Bem-vindo ao Jogo da Forca! ---");
        Console.WriteLine($"Adivinhe a palavra com {palavraSecreta.Length} letras.");

        while (tentativasGastas < maximoDeTentativas && jogadorVenceu == false)
        {
            Console.WriteLine("\n---------------------------------");
            Console.Write("Palavra: ");
            foreach (char letra in letrasDescobertas)
            {
                Console.Write(letra + " ");
            }
            Console.WriteLine($"\nTentativas restantes: {maximoDeTentativas - tentativasGastas}");

            Console.Write("Digite uma letra: ");
            string entrada = Console.ReadLine().ToUpper();
            char chute = entrada[0];

            bool acertouAlgumaLetra = false;
            for (int i = 0; i < palavraSecreta.Length; i++)
            {
                if (palavraSecreta[i] == chute)
                {
                    letrasDescobertas[i] = chute;
                    acertouAlgumaLetra = true;
                }
            }

            if (acertouAlgumaLetra)
            {
                Console.WriteLine("Boa! Você acertou uma letra.");
            }
            else
            {
                Console.WriteLine("Que pena... Essa letra não existe na palavra.");
            }

            tentativasGastas++;

            string palavraFormada = new string(letrasDescobertas);
            if (palavraFormada == palavraSecreta)
            {
                jogadorVenceu = true;
            }
        }

        Console.WriteLine("\n--- Fim de Jogo! ---");
        if (jogadorVenceu)
        {
            Console.WriteLine($"A palavra era: {palavraSecreta}");
            Console.WriteLine($"Parabéns, você acertou! Tentativas: {tentativasGastas}");
        }
        else
        {
            Console.WriteLine($"Não foi dessa vez! A palavra era: {palavraSecreta}.");
        }


    }
}


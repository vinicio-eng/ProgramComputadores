﻿// comentario
/*
 comentarios
varias linhas

tipo nome = valor
 */


//periodo inteiro
//nota primeiro bim float
//nota segundo bim float
//soma de notas float
//media das notas float

string nomeAluno = "Vinicius";
int periodo = 2;
float nota1bim = 7.9f;
float nota2bim = 9.7f;
float somaNotas = nota1bim + nota2bim;
float mediaNotas = somaNotas / 2;

Console.WriteLine(nomeAluno);
Console.WriteLine("Periodo: " + periodo);
Console.WriteLine("Nota Primeiro Bimestre: " + nota1bim);
Console.WriteLine("Nota Primeiro Bimestre: " + nota2bim);
Console.WriteLine("Média Bimestral: " + mediaNotas);

Console.ReadKey();
﻿Console.WriteLine("Vinicius de Almeida Pereira");
Console.WriteLine("André Heber Azeredo Coutinho");
Console.WriteLine("Gustavo Von Scheidt");
Console.WriteLine("Eduardo Gulart da Silva");

Console.WriteLine("--------------------------");


Console.WriteLine("Digite o nome do produto: ");
string produto = Console.ReadLine();
if (produto == "") 
{
    Console.WriteLine("Esta vazio");
    return;
}



Console.WriteLine("Digite a categoria do produto: (Eletronicos, Papelaria ou Moveis");
string categoria = Console.ReadLine();
if (categoria == "") 
{
    Console.WriteLine("Esta vazio");
    return;
}


Console.WriteLine("Digite o valor do produto: ");
string valortxt  = Console.ReadLine();
if (valortxt == "")
{
    Console.WriteLine("Esta vazio");
    return;
}

if (!int.TryParse(valortxt, out int valor))
{
    Console.WriteLine("Digite um valor valido");
    return;
}

decimal desconto = 0;

switch (categoria) 
{
    case "Eletronicos":
        desconto = 15;
        break;

    case "Papelaria":
        desconto = 10;
        break;

    case "Moveis":
        desconto = 5;
        break;

        default:
        Console.WriteLine("Categoria invalida");
        return;
}

decimal valorDesconto = valor - (valor * desconto / 100);

Console.WriteLine($"Produto: {produto}");
Console.WriteLine($"Categoria: {categoria}");
Console.WriteLine($"Valor original: R${valor}");
Console.WriteLine($"Desconto: R${desconto}%");
Console.WriteLine($"Valor a pagar é: R${valorDesconto}");
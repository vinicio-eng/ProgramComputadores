﻿Console.WriteLine("Vinicius de Almeida Pereira");
Console.WriteLine("André Heber Azeredo Coutinho");
Console.WriteLine("Gustavo Von Scheidt");
Console.WriteLine("Eduardo Gulart da Silva");

Console.WriteLine("--------------------------");

Console.WriteLine("Digite um ano: ");
string anotxt = Console.ReadLine();


if (!int.TryParse(anotxt, out int ano))
{
    Console.WriteLine("Digite um valor valido");
    return;
}

bool bissexto = ((ano % 4 == 0 && ano % 100 != 0) || ano % 400 == 0);

if (bissexto) 
{
    Console.WriteLine($"O ano: {ano} é bissexto");
   
}

else
{
    Console.WriteLine($"O {ano} não é bissexto");
}


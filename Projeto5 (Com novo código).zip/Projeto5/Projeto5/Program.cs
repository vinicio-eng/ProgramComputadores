﻿/*
Executar uma rotina
(opicional)Parâmetros: valores de entrada
(opcional)Retorno

retorno NoeMetodo()
{

}

camelcase > variaveis e parâmetros
PascalCase > 


void EscreverOlaMundo()
{
    Console.WriteLine("Hello, World!");
}

EscreverOlaMundo();

void SomarDoisValores(int valor1, int valor2)
{
    //int valor1 = 10;
    //int valor2 = 20;

    int resultsoma = valor1 + valor2;

    Console.WriteLine($"A soma de {valor1} + {valor2} é: {resultsoma}");
}

SomarDoisValores(10, 10); 

int SolicitarValorInteiro()
{
    Console.WriteLine("Digite o valor: ");
    string texto1 = Console.ReadLine();
    int.TryParse(texto1, out int valor1);

    return valor1;
}

int SolicitarValorInteiro2(int valor1, int valor2)
{
    int resultsoma = valor1 + valor2;

    return resultsoma;
}
*/

string RetornaOperador()
{
    Console.WriteLine("+, -, *, /");

    string operador = Console.ReadLine();
    return operador;
}

float RetornarValor()
{
    Console.WriteLine("Digite um valor: ");
    
    float valor = float.Parse(Console.ReadLine());
    return valor;
}

float Somar(float a, float b)
{
    float soma = a + b;
    return soma;
}

float Divisao(float a, float b)
{
    float divisao = a / b;
    return divisao;
}

float Subtracao(float a, float b)
{
    float subtracao  = a - b;
    return subtracao;
}

float Multiplicacao(float a, float b)
{
    float multiplicacao = a + b;
    return multiplicacao;
}

void Calcular()
{
    string operador = RetornaOperador();
    float valor1 = RetornarValor();
    float valor2 = RetornarValor();
    float resultado = 0;


    switch (operador)
    {
        case "+":
            resultado = Somar(valor1, valor2);
            break;

        case "-":
            resultado = Subtracao(valor1, valor2);
            break;

        case "*":
            resultado = Multiplicacao(valor1, valor2);
            break;

        case "/":
            resultado = Divisao(valor1, valor2);
            break;

        default:
            Console.WriteLine("O operador é invalido");
            return;
    }


    Console.WriteLine($"O resultado do calculo é: {resultado} ");
    
}

Calcular();